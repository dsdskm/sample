export const INCREASE = 'increase';
export const DECREASE = 'decrease';
export const RESET = 'reset';
