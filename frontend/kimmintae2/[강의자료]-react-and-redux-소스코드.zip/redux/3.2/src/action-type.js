export const ADD_SECTION = "add section";
export const REMOVE_SECTION = "remove section";
export const START_DISCUSS = "start discuss";
export const STOP_DISCUSS = "stop discuss";
export const TICK_NEXT_TIME = "tick next time";
