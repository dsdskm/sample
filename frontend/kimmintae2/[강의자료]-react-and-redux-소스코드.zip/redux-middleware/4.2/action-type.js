export const INCREASE_COUNTER = 'increase counter';
export const ASYNC_INCREASE_COUNTER = 'async increase counter';
export const DECREASE_COUNTER = 'decrease counter';
export const SET_COUNTER = 'set counter';